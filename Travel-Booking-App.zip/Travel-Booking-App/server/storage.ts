import { db } from "./db";
import {
  destinations,
  bookings,
  type Destination,
  type InsertDestination,
  type Booking,
  type InsertBooking
} from "@shared/schema";
import { eq, ilike } from "drizzle-orm";

export interface IStorage {
  getDestinations(search?: string): Promise<Destination[]>;
  getDestination(id: number): Promise<Destination | undefined>;
  createDestination(destination: InsertDestination): Promise<Destination>;
  
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookings(): Promise<Booking[]>;
}

export class DatabaseStorage implements IStorage {
  async getDestinations(search?: string): Promise<Destination[]> {
    if (search) {
      return await db.select()
        .from(destinations)
        .where(ilike(destinations.name, `%${search}%`));
    }
    return await db.select().from(destinations);
  }

  async getDestination(id: number): Promise<Destination | undefined> {
    const [destination] = await db.select().from(destinations).where(eq(destinations.id, id));
    return destination;
  }

  async createDestination(destination: InsertDestination): Promise<Destination> {
    const [newDestination] = await db.insert(destinations).values(destination).returning();
    return newDestination;
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [newBooking] = await db.insert(bookings).values(booking).returning();
    return newBooking;
  }

  async getBookings(): Promise<Booking[]> {
    return await db.select().from(bookings).orderBy(bookings.createdAt);
  }
}

export const storage = new DatabaseStorage();
