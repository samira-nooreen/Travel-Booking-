import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Destinations
  app.get(api.destinations.list.path, async (req, res) => {
    const search = req.query.search as string | undefined;
    const destinations = await storage.getDestinations(search);
    res.json(destinations);
  });

  app.get(api.destinations.get.path, async (req, res) => {
    const destination = await storage.getDestination(Number(req.params.id));
    if (!destination) {
      return res.status(404).json({ message: 'Destination not found' });
    }
    res.json(destination);
  });

  app.post(api.destinations.create.path, async (req, res) => {
    try {
      const input = api.destinations.create.input.parse(req.body);
      const destination = await storage.createDestination(input);
      res.status(201).json(destination);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Bookings
  app.post(api.bookings.create.path, async (req, res) => {
    try {
      const input = api.bookings.create.input.parse(req.body);
      const booking = await storage.createBooking(input);
      res.status(201).json(booking);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.bookings.list.path, async (req, res) => {
    const bookings = await storage.getBookings();
    res.json(bookings);
  });

  // Seed data if empty
  const existing = await storage.getDestinations();
  if (existing.length === 0) {
    await storage.createDestination({
      name: "Santorini, Greece",
      description: "Beautiful white buildings with blue domes overlooking the sea. Experience the most stunning sunsets and crystal clear waters in the Mediterranean.",
      location: "Cyclades, Greece",
      pricePerNight: 250,
      imageUrl: "https://images.unsplash.com/photo-1613395877344-13d4c79e42d0?auto=format&fit=crop&q=80&w=1000",
      rating: 5
    });
    await storage.createDestination({
      name: "Kyoto, Japan",
      description: "Ancient temples, traditional tea houses, and sublime gardens. Visit during cherry blossom season for an unforgettable experience.",
      location: "Kyoto Prefecture, Japan",
      pricePerNight: 180,
      imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&q=80&w=1000",
      rating: 5
    });
    await storage.createDestination({
      name: "Machu Picchu, Peru",
      description: "The lost city of the Incas, high in the Andes mountains. A breathtaking historical site surrounded by lush cloud forests.",
      location: "Cusco Region, Peru",
      pricePerNight: 120,
      imageUrl: "https://images.unsplash.com/photo-1587595431973-160d0d94add1?auto=format&fit=crop&q=80&w=1000",
      rating: 4
    });
    await storage.createDestination({
      name: "Bali, Indonesia",
      description: "Tropical paradise with lush jungles, volcanic mountains, and iconic rice paddies. Perfect for both relaxation and adventure.",
      location: "Bali, Indonesia",
      pricePerNight: 90,
      imageUrl: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&q=80&w=1000",
      rating: 5
    });
  }

  return httpServer;
}
