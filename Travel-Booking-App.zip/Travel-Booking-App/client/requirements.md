## Packages
framer-motion | Smooth animations for page transitions and interactions
date-fns | Date formatting for booking displays
react-day-picker | Calendar component for selecting booking dates
lucide-react | Beautiful icons for the UI

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
