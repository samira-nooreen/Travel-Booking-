import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertDestination } from "@shared/routes";

export function useDestinations(search?: string) {
  return useQuery({
    queryKey: [api.destinations.list.path, search],
    queryFn: async () => {
      // Construct URL manually since query params aren't in path pattern
      const url = new URL(window.location.origin + api.destinations.list.path);
      if (search) url.searchParams.append("search", search);
      
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch destinations");
      return api.destinations.list.responses[200].parse(await res.json());
    },
  });
}

export function useDestination(id: number) {
  return useQuery({
    queryKey: [api.destinations.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.destinations.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch destination");
      return api.destinations.get.responses[200].parse(await res.json());
    },
    enabled: !isNaN(id),
  });
}

export function useCreateDestination() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertDestination) => {
      const res = await fetch(api.destinations.create.path, {
        method: api.destinations.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.destinations.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create destination");
      }
      return api.destinations.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.destinations.list.path] });
    },
  });
}
