import { type Destination } from "@shared/schema";
import { Link } from "wouter";
import { Star, MapPin, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

interface Props {
  destination: Destination;
}

export function DestinationCard({ destination }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group relative bg-card rounded-3xl overflow-hidden border border-border/50 shadow-sm hover:shadow-xl hover:border-primary/20 transition-all duration-300 h-full flex flex-col"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        {/* Unsplash image with descriptive alt */}
        <img
          src={destination.imageUrl}
          alt={destination.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-60" />
        
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full flex items-center gap-1 shadow-sm">
          <Star className="h-3.5 w-3.5 fill-accent text-accent" />
          <span className="text-xs font-bold text-foreground">{destination.rating}.0</span>
        </div>
      </div>

      <div className="p-6 flex flex-col flex-1">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h3 className="font-display text-xl font-bold text-foreground group-hover:text-primary transition-colors">
              {destination.name}
            </h3>
            <div className="flex items-center gap-1.5 mt-1 text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              <span className="text-sm">{destination.location}</span>
            </div>
          </div>
        </div>

        <p className="text-muted-foreground text-sm line-clamp-2 mt-2 mb-6 flex-1">
          {destination.description}
        </p>

        <div className="flex items-center justify-between mt-auto pt-4 border-t border-border/50">
          <div>
            <span className="text-2xl font-bold text-primary">${destination.pricePerNight}</span>
            <span className="text-xs text-muted-foreground ml-1">/ night</span>
          </div>
          
          <Link href={`/destination/${destination.id}`}>
            <button className="h-10 w-10 rounded-full bg-secondary hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-all duration-300 group/btn">
              <ArrowRight className="h-5 w-5 group-hover/btn:translate-x-0.5 transition-transform" />
            </button>
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
