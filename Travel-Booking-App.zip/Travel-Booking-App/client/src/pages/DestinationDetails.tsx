import { useDestination } from "@/hooks/use-destinations";
import { useCreateBooking } from "@/hooks/use-bookings";
import { useRoute } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema } from "@shared/schema";
import { Loader2, MapPin, Star, Calendar as CalendarIcon, Users, CheckCircle } from "lucide-react";
import { z } from "zod";
import { format, addDays, differenceInDays } from "date-fns";
import { DayPicker } from "react-day-picker";
import "react-day-picker/dist/style.css";
import { useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

// Form schema with date object instead of timestamp string for UI
const formSchema = insertBookingSchema.extend({
  checkIn: z.date({ required_error: "A check-in date is required." }),
  customerName: z.string().min(2, "Name must be at least 2 characters."),
  customerEmail: z.string().email("Please enter a valid email address."),
});

type FormValues = z.infer<typeof formSchema>;

export default function DestinationDetails() {
  const [, params] = useRoute("/destination/:id");
  const id = parseInt(params?.id || "0");
  const { data: destination, isLoading, error } = useDestination(id);
  const { mutate: createBooking, isPending } = useCreateBooking();
  const { toast } = useToast();
  const [date, setDate] = useState<Date | undefined>();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      destinationId: id,
      nights: 1,
      totalPrice: 0,
      customerName: "",
      customerEmail: "",
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <Loader2 className="h-10 w-10 text-primary animate-spin" />
      </div>
    );
  }

  if (error || !destination) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Destination not found</h1>
          <p className="text-muted-foreground">The destination you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  const onSubmit = (data: FormValues) => {
    // Calculate final price based on current state (safeguard)
    const nights = data.nights;
    const totalPrice = nights * destination.pricePerNight;

    createBooking(
      {
        ...data,
        destinationId: id,
        totalPrice,
      },
      {
        onSuccess: () => {
          toast({
            title: "Booking Confirmed!",
            description: "We've sent the details to your email.",
            className: "bg-primary text-primary-foreground",
          });
          form.reset();
          setDate(undefined);
        },
        onError: (err) => {
          toast({
            title: "Booking Failed",
            description: err.message,
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <div className="pb-20">
      {/* Hero Image Header */}
      <div className="h-[50vh] relative w-full overflow-hidden">
        <img
          src={destination.imageUrl}
          alt={destination.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
        <div className="absolute bottom-0 left-0 w-full container max-w-7xl px-4 sm:px-6 lg:px-8 pb-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 text-accent font-medium mb-2">
                <MapPin className="h-5 w-5" />
                <span>{destination.location}</span>
              </div>
              <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">
                {destination.name}
              </h1>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1 bg-white/80 backdrop-blur-sm px-3 py-1 rounded-full border border-white/20">
                  <Star className="h-4 w-4 fill-accent text-accent" />
                  <span className="font-bold">{destination.rating}.0 Rating</span>
                </div>
              </div>
            </div>
            <div className="bg-background/80 backdrop-blur-md p-6 rounded-2xl border border-border shadow-lg">
              <p className="text-sm text-muted-foreground uppercase tracking-wider font-semibold mb-1">Price per night</p>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-display font-bold text-primary">${destination.pricePerNight}</span>
                <span className="text-muted-foreground">USD</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container max-w-7xl px-4 sm:px-6 lg:px-8 mt-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-10">
            <div>
              <h2 className="text-2xl font-display font-bold mb-4">About this destination</h2>
              <p className="text-lg text-muted-foreground leading-relaxed whitespace-pre-line">
                {destination.description}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="bg-secondary/30 p-6 rounded-2xl border border-secondary">
                <Users className="h-8 w-8 text-accent mb-4" />
                <h3 className="font-bold text-lg mb-2">Best for Families</h3>
                <p className="text-muted-foreground text-sm">Spacious accommodations and activities for all ages.</p>
              </div>
              <div className="bg-primary/5 p-6 rounded-2xl border border-primary/10">
                <CheckCircle className="h-8 w-8 text-primary mb-4" />
                <h3 className="font-bold text-lg mb-2">Verified Experience</h3>
                <p className="text-muted-foreground text-sm">Inspected and approved by our travel experts.</p>
              </div>
            </div>
          </div>

          {/* Booking Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-card rounded-3xl border border-border/50 shadow-xl p-6 sm:p-8">
              <h3 className="font-display text-2xl font-bold mb-6">Book your stay</h3>
              
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                
                {/* Date Picker */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Check-in Date</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <button
                        type="button"
                        className={cn(
                          "w-full flex items-center justify-start text-left font-normal px-4 py-3 rounded-xl border border-border bg-background hover:bg-muted/50 transition-colors",
                          !date && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : <span>Pick a date</span>}
                      </button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <DayPicker
                        mode="single"
                        selected={date}
                        onSelect={(d) => {
                          setDate(d);
                          if (d) {
                            form.setValue("checkIn", d);
                          }
                        }}
                        initialFocus
                        disabled={(date) => date < new Date()}
                      />
                    </PopoverContent>
                  </Popover>
                  {form.formState.errors.checkIn && (
                    <p className="text-xs text-destructive">{form.formState.errors.checkIn.message}</p>
                  )}
                </div>

                {/* Nights Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Number of Nights</label>
                  <input
                    type="number"
                    min="1"
                    max="30"
                    className="w-full px-4 py-3 rounded-xl border border-border bg-background focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none transition-all"
                    {...form.register("nights", { valueAsNumber: true })}
                  />
                  {form.formState.errors.nights && (
                    <p className="text-xs text-destructive">{form.formState.errors.nights.message}</p>
                  )}
                </div>

                {/* Personal Info */}
                <div className="space-y-4 pt-4 border-t border-border">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Full Name</label>
                    <input
                      placeholder="John Doe"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-background focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none transition-all"
                      {...form.register("customerName")}
                    />
                    {form.formState.errors.customerName && (
                      <p className="text-xs text-destructive">{form.formState.errors.customerName.message}</p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Email Address</label>
                    <input
                      placeholder="john@example.com"
                      className="w-full px-4 py-3 rounded-xl border border-border bg-background focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none transition-all"
                      {...form.register("customerEmail")}
                    />
                    {form.formState.errors.customerEmail && (
                      <p className="text-xs text-destructive">{form.formState.errors.customerEmail.message}</p>
                    )}
                  </div>
                </div>

                {/* Total Summary */}
                <div className="bg-muted/50 p-4 rounded-xl flex justify-between items-center border border-border/50">
                  <span className="font-medium text-muted-foreground">Total Price</span>
                  <span className="font-display text-2xl font-bold text-primary">
                    ${(form.watch("nights") || 1) * destination.pricePerNight}
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={isPending}
                  className="w-full py-4 rounded-xl font-bold text-lg bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 active:translate-y-0 active:shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none transition-all duration-200"
                >
                  {isPending ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Processing...
                    </span>
                  ) : (
                    "Confirm Booking"
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
