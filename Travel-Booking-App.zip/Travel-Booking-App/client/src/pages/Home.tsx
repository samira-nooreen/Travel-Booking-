import { useDestinations } from "@/hooks/use-destinations";
import { DestinationCard } from "@/components/DestinationCard";
import { Search, Loader2 } from "lucide-react";
import { useState } from "react";
import { motion } from "framer-motion";

export default function Home() {
  const [search, setSearch] = useState("");
  const { data: destinations, isLoading, error } = useDestinations(search);

  return (
    <div className="pb-20">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          {/* Hero background - tropical beach */}
          <img 
            src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2073&auto=format&fit=crop"
            alt="Tropical Beach Paradise"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30 backdrop-blur-[2px]" />
        </div>

        <div className="relative z-10 container max-w-4xl px-4 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="font-display text-5xl md:text-7xl font-bold text-white mb-6 leading-tight"
          >
            Discover Your Next <br/>
            <span className="text-secondary">Great Adventure</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-lg md:text-xl text-white/90 mb-10 max-w-2xl mx-auto"
          >
            Explore handpicked destinations, luxury stays, and unforgettable experiences curated just for you.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            className="bg-white/10 backdrop-blur-md p-2 rounded-2xl max-w-lg mx-auto border border-white/20 shadow-2xl"
          >
            <div className="relative flex items-center">
              <Search className="absolute left-4 h-5 w-5 text-white/70" />
              <input
                type="text"
                placeholder="Where do you want to go?"
                className="w-full h-14 pl-12 pr-4 rounded-xl bg-white/10 border-transparent text-white placeholder:text-white/60 focus:bg-white focus:text-foreground focus:placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent transition-all duration-300"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Destinations Grid */}
      <section className="container max-w-7xl px-4 sm:px-6 lg:px-8 mt-24">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="text-3xl font-display font-bold text-foreground">Popular Destinations</h2>
            <p className="text-muted-foreground mt-2">Find the perfect getaway from our top-rated locations.</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="h-10 w-10 text-primary animate-spin mb-4" />
            <p className="text-muted-foreground">Loading destinations...</p>
          </div>
        ) : error ? (
          <div className="text-center py-20 bg-destructive/5 rounded-3xl border border-destructive/20">
            <h3 className="text-xl font-bold text-destructive mb-2">Something went wrong</h3>
            <p className="text-muted-foreground">We couldn't load destinations. Please try again later.</p>
          </div>
        ) : destinations?.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-xl text-muted-foreground">No destinations found matching "{search}"</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {destinations?.map((destination) => (
              <DestinationCard key={destination.id} destination={destination} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
