import { useBookings } from "@/hooks/use-bookings";
import { useDestinations } from "@/hooks/use-destinations";
import { Loader2, Calendar, MapPin, CreditCard, User } from "lucide-react";
import { format } from "date-fns";
import { Link } from "wouter";

export default function Bookings() {
  const { data: bookings, isLoading: bookingsLoading } = useBookings();
  const { data: destinations } = useDestinations(); // Need destinations to show names/images

  const isLoading = bookingsLoading || !destinations;

  const getDestination = (id: number) => destinations?.find(d => d.id === id);

  return (
    <div className="min-h-screen bg-muted/20 pb-20">
      <div className="bg-white border-b border-border">
        <div className="container max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="font-display text-4xl font-bold text-foreground mb-2">My Bookings</h1>
          <p className="text-muted-foreground text-lg">Manage your upcoming trips and travel history.</p>
        </div>
      </div>

      <div className="container max-w-7xl px-4 sm:px-6 lg:px-8 mt-12">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="h-10 w-10 text-primary animate-spin mb-4" />
            <p className="text-muted-foreground">Loading your adventures...</p>
          </div>
        ) : bookings?.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-border shadow-sm">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
            <h2 className="text-2xl font-display font-bold text-foreground mb-3">No bookings yet</h2>
            <p className="text-muted-foreground max-w-md mx-auto mb-8">
              You haven't booked any trips yet. Start exploring our amazing destinations!
            </p>
            <Link href="/">
              <button className="px-8 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20">
                Explore Destinations
              </button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {bookings?.map((booking) => {
              const destination = getDestination(booking.destinationId);
              if (!destination) return null;

              return (
                <div 
                  key={booking.id}
                  className="bg-card rounded-2xl overflow-hidden border border-border/50 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col md:flex-row"
                >
                  <div className="w-full md:w-48 h-48 md:h-auto shrink-0 relative">
                    <img 
                      src={destination.imageUrl} 
                      alt={destination.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/10" />
                  </div>
                  
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-display text-xl font-bold text-foreground">{destination.name}</h3>
                        <div className="flex items-center gap-1.5 mt-1 text-sm text-muted-foreground">
                          <MapPin className="h-3.5 w-3.5" />
                          <span>{destination.location}</span>
                        </div>
                      </div>
                      <div className="bg-primary/10 px-3 py-1 rounded-full text-xs font-semibold text-primary uppercase tracking-wide">
                        Confirmed
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-y-4 gap-x-6 mb-6">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-secondary/50 flex items-center justify-center text-secondary-foreground">
                          <Calendar className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground font-medium">Check-in</p>
                          <p className="text-sm font-semibold">{format(new Date(booking.checkIn), 'MMM dd, yyyy')}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-secondary/50 flex items-center justify-center text-secondary-foreground">
                          <CreditCard className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground font-medium">Total Paid</p>
                          <p className="text-sm font-semibold">${booking.totalPrice}</p>
                        </div>
                      </div>

                      <div className="col-span-2 flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-secondary/50 flex items-center justify-center text-secondary-foreground">
                          <User className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground font-medium">Guest</p>
                          <p className="text-sm font-semibold">{booking.customerName}</p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-auto pt-4 border-t border-border/50 text-xs text-muted-foreground flex justify-between items-center">
                      <span>Booked on {format(new Date(booking.createdAt || new Date()), 'MMM dd, yyyy')}</span>
                      <span>Booking ID: #{booking.id.toString().padStart(6, '0')}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
